<div class="mb-3">
   <h1 class="h3 d-inline align-middle">{{$title }}</h1>
</div>