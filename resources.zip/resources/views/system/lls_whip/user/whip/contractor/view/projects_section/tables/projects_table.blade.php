<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
    <div class="card flex-fill p-3">
        <div class="card-header" >
            <h5 class="card-title mb-0">Projects</h5>
            <button class="btn btn-primary" data-toggle="modal" data-target="#myModalfour" style="margin:10px 0 20px 0;">Add Project</button>
        </div>
        <div class="table-responsive">
            <table id="data-table-basic" class="table table-striped">
                <thead>
                    <tr>
                        <th>Project Title</th>
                        <th>Project Cost</th>
                        <th>Project Location</th>
                        <th>Status</th>
                   
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>