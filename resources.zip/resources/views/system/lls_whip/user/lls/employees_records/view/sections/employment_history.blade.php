<div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
    <div class="card flex-fill p-3">
        <div class="card-header">
            <h5 class="card-title mb-0">Employment History</h5>
        </div>
        <!-- Data Table area Start-->
        <div class="data-table-area">
            <div class="row">
                <div class="data-table-list">
                    <div class="table-responsive">
                        <table id="data-table-basic" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Establishment</th>
                                    <th>Position</th>
                                    <th>Nature of Employment</th>
                                    <th>Status Of Employment</th>
                                    <th>Level Of Employment</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>