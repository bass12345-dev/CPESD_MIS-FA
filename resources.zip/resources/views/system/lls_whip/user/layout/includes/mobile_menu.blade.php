    <!-- Mobile Menu start -->
    <div class="mobile-menu-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="mobile-menu">
                        <nav id="dropdown">
                            <ul class="mobile-menu-nav">

                            <h3>LABOR LOCALIZATION</h3>
                                <li><a data-toggle="collapse" data-target="#Charts" href="#">Home</a>
                                    <ul class="collapse dropdown-header-top">
                                        <li><a href="index.html">Dashboard</a></li>
                                    <li><a href="analytics.html">Analytics</a></li>
                                    </ul>
                                </li>
                                <li><a data-toggle="collapse" data-target="#demoevent" href="#">Establishments</a>
                                    <ul id="demoevent" class="collapse dropdown-header-top">
                                        <li><a href="inbox.html">Add New</a></li>
                                        <i><a href="view-email.html">View Establishments</a></li>
                                    </ul>
                                </li>
                               
                                <h3>WHIP</h3>

                                <li><a data-toggle="collapse" data-target="#Charts1" href="#">Home</a>
                                    <ul class="collapse dropdown-header-top">
                                        <li><a href="index.html">Dashboard</a></li>
                                        <li><a href="analytics.html">Analytics</a></li>
                                    </ul>
                                </li>
                                <li><a data-toggle="collapse" data-target="#demoevent1" href="#">Contractors</a>
                                    <ul class="collapse dropdown-header-top">
                                        <li><a href="inbox.html">Add New</a></li>
                                        <i><a href="view-email.html">View Establishments</a></li>
                                    </ul>
                                </li>
                                
                            </ul>

                            
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Mobile Menu end -->