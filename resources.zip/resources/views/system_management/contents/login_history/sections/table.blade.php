<div class="card flex-fill p-3">
    <div class="card-header">
        @include('components.dts.filter_by_month')
    </div>
    <table class="table table-hover" id="datatables" style="width: 100%; ">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Date And Time</th>
            </tr>
        </thead>

    </table>
</div>