<div class="row header_title_container" >
        <h1>{{$row->establishment_name}}</h1>
    </div>