<div class="card-header d-flex">
    <button class="btn btn-primary " id="all_data" style="margin-right: 10px;">Show All Data</button>
    <input id='calendar' name="month" class="form-control w-25" value="{{$current}}" />
    <button class="btn btn-success" id="by-month" style="margin-left:2px;">Submit</button>
</div>