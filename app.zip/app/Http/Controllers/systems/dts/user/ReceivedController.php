<?php

namespace App\Http\Controllers\systems\dts\user;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ReceivedController extends Controller
{
    //
}
